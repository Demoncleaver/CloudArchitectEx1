# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["ResponseFormatTextGrammar"]


class ResponseFormatTextGrammar(BaseModel):
    """
    A custom grammar for the model to follow when generating text.
    Learn more in the [custom grammars guide](https://developers.openai.com/api/docs/guides/function-calling#context-free-grammars).
    """

    grammar: str
    """The custom grammar for the model to follow."""

    type: Literal["grammar"]
    """The type of response format being defined. Always `grammar`."""
