# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import TypeAlias

__all__ = ["AutomationMetadataParam"]

AutomationMetadataParam: TypeAlias = Dict[str, str]
