# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Optional
from typing_extensions import Required, TypeAlias, TypedDict

from .beta_response_input_file_param import BetaResponseInputFileParam
from .beta_response_input_text_param import BetaResponseInputTextParam
from .beta_response_input_image_param import BetaResponseInputImageParam

__all__ = ["BetaResponsePromptParam", "Variables"]

Variables: TypeAlias = Union[str, BetaResponseInputTextParam, BetaResponseInputImageParam, BetaResponseInputFileParam]


class BetaResponsePromptParam(TypedDict, total=False):
    """
    Reference to a prompt template and its variables.
    [Learn more](https://developers.openai.com/api/docs/guides/text?api-mode=responses#version-prompts-in-code).
    """

    id: Required[str]
    """The unique identifier of the prompt template to use."""

    variables: Optional[Dict[str, Variables]]
    """Optional map of values to substitute in for variables in your prompt.

    The substitution values can either be strings, or other Response input types
    like images or files.
    """

    version: Optional[str]
    """Optional version of the prompt template."""
