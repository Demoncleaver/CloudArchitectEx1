# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["BetaResponseInputText", "PromptCacheBreakpoint"]


class PromptCacheBreakpoint(BaseModel):
    """Marks the exact end of a reusable prompt prefix.

    When `ttl` is omitted, the breakpoint inherits the request's `prompt_cache_options.ttl`; the boundary is not rounded to a token block.
    """

    mode: Literal["explicit"]
    """The breakpoint mode. Always `explicit`."""

    ttl: Optional[Literal["30m", "12h"]] = None
    """The minimum lifetime of this cache breakpoint. Defaults to the request TTL."""


class BetaResponseInputText(BaseModel):
    """A text input to the model."""

    text: str
    """The text input to the model."""

    type: Literal["input_text"]
    """The type of the input item. Always `input_text`."""

    prompt_cache_breakpoint: Optional[PromptCacheBreakpoint] = None
    """Marks the exact end of a reusable prompt prefix.

    When `ttl` is omitted, the breakpoint inherits the request's
    `prompt_cache_options.ttl`; the boundary is not rounded to a token block.
    """
